<footer class="main-footer">
    <strong>Copyright &copy;2022 <a href="https://www.facebook.com/dinosaur.palestine">Dinosaure</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">

    </div>
  </footer>
<?php /**PATH C:\xampp\htdocs\optical\resources\views/layouts/footer.blade.php ENDPATH**/ ?>