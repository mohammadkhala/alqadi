<!-- jQuery -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- ChartJS -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/chart.js/Chart.min.js')); ?>"></script>
<!-- Sparkline -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/sparklines/sparkline.js')); ?>"></script>
<!-- JQVMap -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
<!-- jQuery Knob Chart -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
<!-- daterangepicker -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/moment/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<!-- Summernote -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script  type="text/javascript" src="<?php echo e(URL::asset('assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->

<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\optical\resources\views/layouts/footer-scripts.blade.php ENDPATH**/ ?>